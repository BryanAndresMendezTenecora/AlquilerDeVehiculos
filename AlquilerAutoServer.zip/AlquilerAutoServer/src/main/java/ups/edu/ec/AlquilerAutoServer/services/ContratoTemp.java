package ups.edu.ec.AlquilerAutoServer.services;

public class ContratoTemp {

	private String mensaje;
}
