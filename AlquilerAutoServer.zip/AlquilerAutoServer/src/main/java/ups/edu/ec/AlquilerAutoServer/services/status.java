package ups.edu.ec.AlquilerAutoServer.services;

public class status {
	private String status; 
	private result result;
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public result getResult() {
		return result;
	}
	public void setResult(result result) {
		this.result = result;
	}
	
	

}
