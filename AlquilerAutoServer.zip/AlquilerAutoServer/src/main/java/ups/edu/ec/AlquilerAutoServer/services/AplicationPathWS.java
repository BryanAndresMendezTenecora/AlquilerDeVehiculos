package ups.edu.ec.AlquilerAutoServer.services;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("/ws")
public class AplicationPathWS extends Application {

}
